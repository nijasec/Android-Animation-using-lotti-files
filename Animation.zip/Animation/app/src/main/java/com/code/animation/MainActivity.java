package com.code.animation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

public class MainActivity extends AppCompatActivity {

    LottieAnimationView lot;
    boolean isplay=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton imgbtn=findViewById(R.id.imageButton);
       lot =findViewById(R.id.lotanim);
        lot.setAnimation(R.raw.jumping_emoji);
        final TextView hello=findViewById(R.id.tv);

        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hello.setText("Button clicked");
                if(!isplay) {
                    lot.playAnimation();
                    isplay=true;
                }
                else {
                    lot.pauseAnimation();
                    isplay=false;
                }
            }
        });
    }
}